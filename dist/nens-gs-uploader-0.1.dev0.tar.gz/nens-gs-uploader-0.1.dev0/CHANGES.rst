Changelog of nens-gs-uploader
===================================================


0.1 (unreleased)
----------------

- Initial project structure created with cookiecutter and
  https://github.com/nens/cookiecutter-python-template
