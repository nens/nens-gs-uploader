# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 13:25:44 2019

@author: chris.kerklaan - N&S
"""
production_lizard = {
    "host": "p-product-db-d1.external-nens.local",
    "port": "5432",
    "database": "productie-geoserver",
    "username": "productie-geoserver",
    "password": "ww",
}
production_klimaatatlas = {
    "host": "p-product-db-d1.external-nens.local",
    "port": "5432",
    "database": "klimaatatlas-geoserver-v2",
    "username": "klimaatatlas-geoserver",
    "password": "ww",
}
production_flooding = {
    "host": "xxxx",
    "port": "5432",
    "database": "xx",
    "username": "xx",
    "password": "ww",
}
project_klimaatatlas = {
    "host": "p-project-db-d1.external-nens.local",
    "port": "5432",
    "database": "p-project-map-d1",
    "username": "klimaatatlas-project-geoserver",
    "password": "ww",
}
project_lizard = {
    "host": "p-project-db-d1.external-nens.local",
    "port": "5432",
    "database": "p-project-map-d1",
    "username": "klimaatatlas-project-geoserver",
    "password": "ww",
}
staging = {
    "host": "s-project-db-d1.external-nens.local",
    "port": "5432",
    "database": "staging-project-geoserver",
    "username": "staging-project-geoserver",
    "password": "ww",
}
production_klimaatatlas_v1 = {
    "host": "p-product-db-d1.external-nens.local",
    "port": "5432",
    "database": "klimaatatlas-geoserver",
    "username": "klimaatatlas-geoserver",
    "password": "ww",
}

username = "username"
password = "wachtwoord"
