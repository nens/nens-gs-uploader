# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 13:25:44 2019

@author: chris.kerklaan - N&S
"""
production_lizard = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}
production_klimaatatlas = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}
project_klimaatatlas = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}
project_lizard = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}
staging = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}
production_klimaatatlas_v1 = {
    "host": "",
    "port": "",
    "database": "",
    "username": "",
    "password": "",
}

username = ""
password = ""
